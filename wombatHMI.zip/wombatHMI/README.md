# WOMBAT-HMI

You'll need [Node](https://nodejs.org/) v16 or higher

Once installed, extract this wombatHMI.zip to the Desktop. (Or anywhere you want if you can navigate directories in cmd)

Then open Command Prompt

Navigate to extracted folder in Command Prompt via:

cd Desktop\wombatHMI

Then type:

npm install

Then type:

npm start

Then go to the localhost CMD says in your internet browser, pretty sure it'll be:

http://localhost:1234/

The OpenLayers should be there and it should have 3 WOMBATs just north of the Joondalup Campus.
![cmdExample](https://user-images.githubusercontent.com/92205638/165839445-540032d7-9107-48bc-ace0-33f5a7dbd2be.jpg)
![localhostExample](https://user-images.githubusercontent.com/92205638/165839450-e0d78aa6-7fbe-44db-8ff5-ebea8f13ddb5.jpg)
